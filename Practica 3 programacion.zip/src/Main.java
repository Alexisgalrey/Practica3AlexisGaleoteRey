public class Main {
    public static void main(String[] args) {
pais p = new pais ();

p.setNombre("España");
        System.out.println("El pais es " + p.getNombre());
p.setContinente("Europa");
        System.out.println("Pertenece al continente de " + p.getContinente());
p.setIdiomaOficial("Castellano");
        System.out.println("Su idioma oficial es el " + p.getIdiomaOficial());
p.setExtensionGeografica(506.030);
        System.out.println("Su extension geografica es de " + p.getExtensionGeografica() + "Km2");

        pais p2 = new pais ("Francia");

        p.setNombre("Francia");
        System.out.println("El pais es " + p.getNombre());
        p.setContinente("Europa");
        System.out.println("Pertenece al continente de " + p.getContinente());
        p.setIdiomaOficial("Frances");
        System.out.println("Su idioma oficial es el " + p.getIdiomaOficial());
        p.setExtensionGeografica(551.695);
        System.out.println("Su extension geografica es de " + p.getExtensionGeografica() + "Km2");

        pais p3 = new pais ();

        p.setNombre("Peru");
        System.out.println("El pais es " + p.getNombre());
        p.setContinente("America");
        System.out.println("Pertenece al continente de " + p.getContinente());
        p.setIdiomaOficial("Castellano");
        System.out.println("Su idioma oficial es el " + p.getIdiomaOficial());
        p.setExtensionGeografica(551.695);
        System.out.println("Su extension geografica es de " + p.getExtensionGeografica() + "Km2");

//EJERCICIO 3


    }
}